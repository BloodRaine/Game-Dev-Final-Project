Outline
=======

Hometown
--------

-   House is on fire, parents taken.
-   Vivians finds out reason, leaves to confront EvilCorp.

Aether Wilds (Forest)
---------------------

-   Vivian meets <quirky_character_1>.
-   Vivian fights first creature battles.

City #1
-------

-   City with completely non-augmented population.
-   Poorest city of the 3 (but more populated than Vivian's hometown).
-   Vivian finds out more about EvilCorp, gets new cards.
-   Vivian must defeat main boss in city before leaving.

Mountains
---------

-   Vivian meets <quirky_character_2>.
-   Vivian fights more creature battles.

City #2
-------

-   *Transition*: Vivian has some trouble getting into this city.
-   There are a few augmented citizens who lead the city of mostly non-augmented
    citizens.
    -   This city somewhat more prosperous than City #1, still huge gap to City
        #3.
    -   Morals of augmented leadesr questionable. They don't allow everyone into
        the city.
-   *Transition*: Vivian warned of dangers of the desolate wasteland.
    -   Must go through wasteland to get to City #3. May try this and die. The
        ones who do make it cannot enter City #3 so easily.

Desolate Wasteland
------------------

-   Physical and metaphorical separation of classes.
-   Vivian has to fight her way through the Wasteland's creatures.
-   Vivian becomes too worn, passes out.

City #3
-------

-   *Transition*: Vivian wakes up to meet <quirky_character_3>, whose has a
    hideout along the outskirts of the city. Vivian proves her worth by battling
    <quirky_character_3>, who then gives her directions to EvilCorp.
-   Vivian makes her way to EvilCorp, hiding her identity along the way. She
    fights a few battles, with one of her opponents finding out that she's in
    the city illegal.
-   The information is given to EvilCorp, and she is summoned to their HQ.

EvilCorp
--------

-   Final confrontation happens here.
-   Vivian finds her father, who is disoriented and confusing.
-   Vivians finds her mother and head of augmented reality project.
-   Vivian fights head of augmented reality project, wins.
-   Vivian finds out that her dad became addicted to the drug Epsilon while at
    company, hence his confusing remarks before. Turns out he staged the fire
    and kidnapping himself to feed his addiction.
-   Vivian confronts father, emotional stuff happens.
-   CEO of company activates augmented reality on himself.
-   Father vowes to make it up to Vivian and mother, he had been planning his
    escape. He activates augmented reality system on himself as well.
-   Vivian and Father face CEO together, Father sacrifices himself to end it.
-   The end :)


