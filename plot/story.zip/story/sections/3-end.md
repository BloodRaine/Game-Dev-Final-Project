Climax
======

The girl arrives at Corporation's HQ, ready to fight her way through the ranks
to save her parents.

[Girl fights through ranks.]

Partway through her ascension through the HQ, the girl finds her father passed
out. She tries to awaken him, but he is unresponsive aside from a few groans and
incomprehensible mutterings. She begins to leave the room, when she hears her
name. She rushes back to her father, who is slowly opening his eyes, a slight
smile on his face.

The girls asks her father what happened, assuming that he'd been maliciously
knocked unconscious by an antagonistic Corporation employee. Her father, slowly
coming-to, begins to explain.

Harrison: "Emmeleia...heh...what are you doing here?" *coughs*
Emmeleia: "Harrison, who did this to you?"
Harrison: "Heh, don't worry about me. How are you? Have you been hurt?"
Emmeleia: "Father, you were lying unconscious on the floor!"
Harrison: "Heh, I suppose I was, wasn't I?"
Harrison: *shakes head vigorously*
Harrison: "Whew, sorry about that. Have you seen your mother?"
Emmeleia: "Not yet...is she safe?"
Harrison: "I'm sure she's fine, but you should go find her to be sure."

Emmeleia's father rolls over, revealing a black patch in the shape of a Greek
epsilon.

Emmeleia: "Fa-father...is that...what have they been doing to you?!"
Harrison: "Emm, I'm okay, I promise you. I was knocked over by an employee
           who was rushing to secure the system upon your arrival. It seems
           you've stirred up quite the ruckus recently."
Emmeleia: "Of course I have, I was worried about you and Mother! And I'm glad
           you weren't knocked unconscious maliciously, but...that patch on your
           arm, have they been..." *tears up*
Harrison: "No, Em. Listen, I have to tell you what's been going on here. It
           won't be easy for you to hear, but I swear to you that it's the
           truth."
Emmeleia: "Okay..."

