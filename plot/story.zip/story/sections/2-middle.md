Middle
======

Vivian sets out on her journey, trying not to think about the sheer scale of the
path she has just set out on. Part of her is very much aware of the position she
is in: a girl, too young to fly a SteamShip and always uncomfortable being the
center of attention, is about to journey by herself to a multi-national
corporation's headquarters and demand her parents be released. Nonetheless, she
does her best to ignore her own fears and doubts of her abilities and presses
on.

City #1
-------


Aether Wilds
------------


City #2
-------


Mountains
---------


City #3
-------


Desolate Wasteland
------------------


